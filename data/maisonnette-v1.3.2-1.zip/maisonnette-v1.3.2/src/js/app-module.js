var App = (function () {

  App.moduleName = function( ){
    'use strict'

    //Js Code
    
  };

  return App;
})(App || {});
